module.exports = {  
    entry: "./js/test.js",  
    output: {  
        path: "./build",  
        filename:"bundle.js"  
    },
    module: {
          //加载器配置
        loaders: [
            { test: /\.css$/, loader: 'style-loader!css-loader' },
            // { test: /\.js$/, loader: 'jsx-loader?harmony' },
            { test: /\.scss$/, loader: 'style!css!sass'}
        ]
    },  
} 