window.onload=function(){
	require('../scss/test.scss'); //加载初始化样式
	var cardInput = document.getElementById('card-num');
	var cardTips = document.getElementById('card-tips');
	var errorTips = document.getElementById('error-tips');
	cardInput.onfocus = function() {
		// 获得焦点：表单提示隐藏，卡号提示在有非空格字符条件下显示
		if(trim(cardInput.value).length > 0) {
			cardTips.setAttribute('class','');
		}
		cardInput.setAttribute('class','')
		errorTips.setAttribute('class','hidden');
	};
	cardInput.onblur = function() {
		// 失去焦点：卡号提示隐藏，表单提示显示
		cardTips.setAttribute('class','hidden');
		var msg = '';
		var reg = /^(\d{16}|\d{19})$/;
		if(trim(cardInput.value).length == 0) {
			msg = '请输入银行卡号';
		} else if(!reg.test(trim(cardInput.value))) {
			msg = '银行卡号为16位或19位数字';
		errorTips.innerHTML = msg;
		}
		(msg == '')?(cardInput.setAttribute('class','')):(cardInput.setAttribute('class','error'));
		errorTips.setAttribute('class','');
	};
	cardInput.onkeyup = function() {
		// 有除空格以外的字符时显示，否则隐藏
		if(trim(cardInput.value).length > 0) {
			cardTips.innerHTML = cardInput.value.replace(/\s/g,'').replace(/(\d{4})(?=\d)/g,"$1 ");
			cardTips.setAttribute('class','');
		} else {
			cardTips.setAttribute('class','hidden');
		}
	}
}
// 去左右空格
function trim(str) {
	return str.replace(/^\s+|\s+$/g,'');
}
